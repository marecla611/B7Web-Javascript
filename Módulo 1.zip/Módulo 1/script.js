// Módulo 1 - B7Web

// Testando outputs

document.getElementById("titulo").innerHTML = "Tudo bem?";

document.write("Algum texto");

window.alert("Mensagem de exemplo");

console.log("A mensagem que eu inserir aqui vai aparecer no console do navegador.");

// Testando variáveis

var idade = 19;
var nome = "Marcela";
var sobrenome = " Amorim";
var nomecompleto = nome + sobrenome;

alert (nomecompleto);
alert (idade);

var x = 10;
var y = 15;

var total = x + y;

alert (total);

// Condicionais

var hora = 18;

// Se hora for maior ou igual a 12 E menor que 18
if (hora >= 12 && hora < 18) {
	console.log("Boa tarde");
}

// Se hora for igual a 12 OU igual a 18
if (hora == 12 || hora == 18) {
	console.log("Você está na hora do rush");
}


