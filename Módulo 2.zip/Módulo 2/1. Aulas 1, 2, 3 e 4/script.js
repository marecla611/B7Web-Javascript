// Módulo 2 - Aula 2

// Alterando o elemento localizado no HTML utilizando o JavaScript e a ID do elemento
document.getElementById('exemplo').innerHTML = "Amorim";

// Alterando o elemento localizado no HTML utilizando o JavaScript e a CLASSE do elemento
document.getElementsByClassName('lista')[0].innerHTML = "Item alterado";

// Seleciona o elemento pelo tipo da TAG
document.getElementsByTagName('button'); // Rodar esse no console para entender melhor

// Seleciona o elemento pelo nome
document.getElementsByName('e-mail'); // Rodar esse no console para entender melhor

// Selecionando a segunda classe "lista" e alterando o valor dentro dela. Lembrando que a contagem começa a partir de 0.
document.querySelectorAll('.lista')[1].innerHTML = 'Também alterado!';