// Estudando funções

function alterar(titulo) {
	document.getElementById("titulo").innerHTML =titulo;
	document.getElementById("campo").value = titulo;
}

// Aqui a função está sendo chamada para rodar
alterar("Tudo foi trocado");

function somar(x, y) {
	let total = x + y;

	return total;
}

var resultado = somar(10, 15);

console.log(resultado);