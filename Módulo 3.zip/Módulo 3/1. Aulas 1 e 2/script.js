function clicou(){
	alert("Você clicou no botão");
}

function digitou(e){
	console.log("Você digitou");
	if (e.keyCode == 13) {
		let texto = document.getElementById("campo").value;

		console.log(texto);
	}
}