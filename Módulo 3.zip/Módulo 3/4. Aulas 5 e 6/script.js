// Estudando objetos

let carros = [
	'Palio',
	'Uno',
	'Corolla',
	'Ferrari',
	// Gravando NOME e MODELO em apenas um item de array
	{nome: 'Onix', modelo: 'Chevrolet'},
];

let carro = {
	nome: 'Fiat',
	modelo: 'Uno',
	peso: '800kg',
	ligado: false,
	// Função para transformar LIGADO em TRUE
	ligar: function() {
		// THIS: Existe somente DENTRO de um objeto, e é acessado somente de dentro deste objeto.
		this.ligado = true;
		console.log('VRUM VRUUUUUUM RATATATATA');
	},
	acelerar: function() {
		if (this.ligado == true) {
			console.log("ZIUUUUUUM");
		} else {
			console.log(this.nome+" "+this.modelo+" não está ligado.");
		}
	}
};

console.log(carros);
console.log(carro.nome);

// Se essa função for retirada, o ELSE entra em ação
carro.ligar();
carro.acelerar();