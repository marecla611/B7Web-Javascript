//Arrays

let carros = ['Palio', 'Uno', 'Corolla', 'Ferrari'];

console.log(carros);

let ingredientes = [
	//Array dentro de array. Neste caso, temos apenas dois itens

	//Item 1
	['uva', 'pera', 'maçã'],

	//Item 2
	['alface', 'pepino', 'xuxu'],
];

console.log(ingredientes);

//Especificando o que eu quero que seja mostrado
console.log(ingredientes[1][1]);