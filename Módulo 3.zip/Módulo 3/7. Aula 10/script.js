// Estudando FOR LOOP e FOR ARRAY

let texto = '';
let carros = ['Ferrari', 'Fusca', 'Palio', 'Corolla'];

// FOR LOOP
// for(variável auxiliar; condição; incrementação)
for (let i = 1; i <= 10; i++) {
	texto = texto + i + '<br/>';
}

// FOR ARRAY
let html = '<ul>';

for (let i in carros) {
	html += '<li>' + carros[i] + '</li>';
}

html += '</ul>';

document.getElementById("demo").innerHTML = texto;

document.getElementById("demoCarros").innerHTML = html;