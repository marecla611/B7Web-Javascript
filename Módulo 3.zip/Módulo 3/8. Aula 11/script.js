// Estudando LOOP WHILE

let html = '';

let c = 0;

while(c <= 10) {
	html += "Número: " + c + "<br>";
	c++;
}

// O mesmo código no LOOP FOR

for (let c = 1; c <= 10; c++) {
	html += "<br>" + "Número: " + c;
}

document.getElementById("demo").innerHTML = html;